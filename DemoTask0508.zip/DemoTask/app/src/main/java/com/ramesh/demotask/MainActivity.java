package com.ramesh.demotask;

import android.content.ContentResolver;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.preference.PreferenceManager;
import android.provider.ContactsContract;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static java.util.Objects.isNull;

public class MainActivity extends AppCompatActivity {

    EditText et_email,et_number;
    String email="";
   String number;
    Button btnSubmit;

    public String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    private ArrayList<Data> dataArrayList;
    NewRecylcerviewAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );
        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        et_number = (EditText) findViewById(R.id.et_number);
        et_email = (EditText) findViewById(R.id.et_email);

        loadData();
       ArrayList<Data> dataArrayList=new ArrayList<>();

        btnSubmit = (Button) findViewById(R.id.btnSubmit);
        btnSubmit.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                email=et_email.getText().toString();
                number=  et_number.getText().toString();
                if (isNull(email)) {
                    showErrorSnack("Please enter Email ");
                    et_email.requestFocus();
                    return;
                }
                if (!email.matches(emailPattern)) {
                    showErrorSnack("Enter valid email");
                    et_email.requestFocus();
                    return;
                }

                if (isNull(number)) {
                    showErrorSnack("Please enter Mobile No:");
                    et_number.requestFocus();
                    return;
                }
//                mAppPreferences.setEmployeeId( email );
//                mAppPreferences.setNUmber( number );
                dataArrayList.add(new Data(et_email.getText().toString(), et_number.getText().toString()));
                // notifying adapter when new data added.
                adapter.notifyItemInserted(dataArrayList.size());

            }
        } );

        adapter = new NewRecylcerviewAdapter(dataArrayList, MainActivity.this);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        RecyclerView.ItemAnimator itemAnimator = new DefaultItemAnimator();
        itemAnimator.setAddDuration(1000);

        recyclerView.setItemAnimator(itemAnimator);



    }




    public void showErrorSnack(String msg) {
        // TODO Auto-generated method stub
        final ViewGroup viewGroup = (ViewGroup) ((ViewGroup) this.findViewById(android.R.id.content)).getChildAt(0);
        Snackbar snackbar = Snackbar.make(viewGroup, Html.fromHtml("<b>" + msg + "</b>"), Snackbar.LENGTH_LONG);
        View view = snackbar.getView();
        view.setBackgroundColor( Color.parseColor("#ed008c"));
        snackbar.show();
    }
    public boolean isNull(String charSequence) {
        return charSequence == null || charSequence.length() == 0;
    }




    private void loadData() {
        SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);

        // creating a variable for gson.
        Gson gson = new Gson();

        // below line is to get to string present from our
        // shared prefs if not present setting it as null.
        String json = sharedPreferences.getString("courses", null);

        // below line is to get the type of our array list.
        Type type = new TypeToken<ArrayList<Data>>() {}.getType();

        // in below line we are getting data from gson
        // and saving it to our array list
        dataArrayList = gson.fromJson(json, type);

        // checking below if the array list is empty or not
        if (dataArrayList == null) {
            // if the array list is empty
            // creating a new array list.
            dataArrayList = new ArrayList<>();
        }
    }

    private void saveData() {
        // method for saving the data in array list.
        // creating a variable for storing data in
        // shared preferences.
        SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);

        // creating a variable for editor to
        // store data in shared preferences.
        SharedPreferences.Editor editor = sharedPreferences.edit();

        // creating a new variable for gson.
        Gson gson = new Gson();

        // getting data from gson and storing it in a string.
        String json = gson.toJson(dataArrayList);

        // below line is to save data in shared
        // prefs in the form of string.
        editor.putString("courses", json);

        // below line is to apply changes
        // and save data in shared prefs.
        editor.apply();

        // after saving data we are displaying a toast message.
        Toast.makeText(this, "Saved Array List to Shared preferences. ", Toast.LENGTH_SHORT).show();
    }

}