package com.ramesh.demotask;


import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

public class NewRecylcerviewAdapter extends RecyclerView.Adapter<NewRecylcerviewAdapter.ViewHolder> {

        // creating a variable for array list and context.
        private ArrayList<Data> courseModalArrayList;
        private Context context;

        // creating a constructor for our variables.
        public NewRecylcerviewAdapter(ArrayList<Data> courseModalArrayList, Context context) {
            this.courseModalArrayList = courseModalArrayList;
            this.context = context;
        }

        @NonNull
        @Override
        public NewRecylcerviewAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            // below line is to inflate our layout.
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_layout_view, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull NewRecylcerviewAdapter.ViewHolder holder, int position) {
            // setting data to our views of recycler view.
            Data modal = courseModalArrayList.get(position);
            holder.email.setText(modal.getEmail());
            holder.name.setText(modal.getNumber());
        }

        @Override
        public int getItemCount() {
            // returning the size of array list.
            return courseModalArrayList.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {

            // creating variables for our views.
            private TextView email, name;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);

                // initializing our views with their ids.
                email = (TextView) itemView.findViewById(R.id.email);
                name = (TextView) itemView.findViewById(R.id.name);
            }
        }

}
