package com.ramesh.demotask;

public class Data {
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    String email,number;

    @Override
    public String toString() {
        return "Data{" +
                "email='" + email + '\'' +
                ", number='" + number + '\'' +
                '}';
    }

    public Data(String email, String number) {
        this.email = email;
        this.number = number;
    }
}
